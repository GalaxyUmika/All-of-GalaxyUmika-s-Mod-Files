definemod{'bgkick', function(p)
	bg:xywh(scx,scy,sw+p,sh+p)
end}

definemod{'bgzoomy', function(p)
	bg:zoomy(p)
end}

definemod{'bgzoomx', function(p)
	bg:zoomx(p)
end}

definemod{'bgrotate', function(p)
	bg:rotationz(p)
end}

definemod{'bgbounce', function(p)
	bg:y(p)
end}

definemod{'bgrotatex', function(p)
	bg:rotationx(p)
end}

definemod{'bgrotatey', function(p)
	bg:rotationy(p)
end}