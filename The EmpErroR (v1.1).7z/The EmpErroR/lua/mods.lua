-- help i fucked up the cut at 0:57.04 please forgive me

if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end

definemod{'bgzoom', function(p)
	ITG2BG:zoom(1+p)
end}

definemod{'bgzoomy', function(p)
	ITG2BG:zoomy(p)
end}

definemod{'bgzoomx', function(p)
	ITG2BG:zoomx(p)
end}

definemod{'bgrotate', function(p)
	ITG2BG:rotationz(p)
end}

	local p1DefaultX = P1:GetX()
local p2DefaultX = P2:GetX()
local defaultZ = P1:GetZ()

definemod { 'centerPlayfields', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end }

definemod { 'centerP1', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
end }

definemod { 'centerP2', function(percent) 
    local scale = percent / 100
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end } --i didnt write that mod starundrscre did it, credit to them ig

condor_const1 = math.sqrt(math.pow(SCREEN_WIDTH/2,2)+math.pow(SCREEN_HEIGHT/2,2))
	condor_const2 = 180+math.deg(math.atan(SCREEN_HEIGHT/SCREEN_WIDTH))
	function condor_screenmotion(zm,ang,x,y)
		if not x then x = SCREEN_WIDTH/2 end
		if not y then y = SCREEN_HEIGHT/2 end

		local screen = SCREENMAN:GetTopScreen()

		screen:x(x+(condor_const1*zm*math.cos((ang+condor_const2)/180*math.pi)));
		screen:y(y+(condor_const1*zm*math.sin((ang+condor_const2)/180*math.pi)));
		screen:rotationz(ang)
		screen:zoom(zm)
	end

	definemod {'screenzoom', 'screenrotate', function(zm, ang)
		condor_screenmotion(zm,ang)
	end}

definemod {'myreverse0', -50, 'split', -50, 'cross', -50, 'alternate', 100, 'reverse'}


-- code from "Hurry Hurry"!
ITG2BG:zoomtowidth(SCREEN_WIDTH)
	ITG2BG:zoomtoheight(SCREEN_HEIGHT)
	ITG2BG:x(SCREEN_CENTER_X)
	ITG2BG:y(SCREEN_CENTER_Y)
	ITG2BG:diffuse(0.5, 0.5, 0.5, 1)
setdefault {2.1,'xmod',100,'overhead',1,'screenzoom',100,'dizzyholds',100,'modtimer',-50,'bumpyxoffset',-300,'bumpyxperiod',-1, 'bgzoom',100,'cover',200,'mini'}

ease {0,1,outBack,0,'bgzoom'}

ease {0,1,outBack,0,'mini'}

for i=4,7.75,1 do
ease {i,0.5,instant,75,'tipsy'}
ease {i+0.5,0.5,instant,-75,'tipsy'}
ease {i,0.5,instant,35,'drunk'}
ease {i+0.5,0.5,instant,-35,'drunk'}
end
ease {8,3,outElastic,0,'tipsy',0,'drunk'}

for i=8,35,2 do
ease {i,0.75,outBack,3,'alternate',-1.5,'reverse'}
ease {i+1,0.75,outBack,-3,'alternate',1.5,'reverse'}
end


for i=36,39.75,1 do
ease {i,.5,instant,6,'alternate',-3,'reverse'}
ease {i+.5,.5,instant,-6,'alternate',3,'reverse'}
end

for i=40,54,4 do
ease {i,0.75,outBack,8,'alternate',-4,'reverse'}
ease {i+2,0.75,outBack,-8,'alternate',4,'reverse'}
end

ease {56,0.75,outBack,0,'alternate',0,'reverse'}
ease {56,0.75,outBack,0,'alternate',0,'reverse'}

for i=56,63,1 do
ease {i,1,bounce,-35,'movey'}
end

for i=64,71.5,1 do
ease {i,0.5,instant,50,'tipsy'}
ease {i+0.5,0.5,instant,-50,'tipsy'}
ease {i,0.5,instant,35,'drunk'}
ease {i+0.5,0.5,instant,-35,'drunk'}
ease {i,0.5,instant,10,'noteskew'}
ease {i+0.5,0.5,instant,-10,'noteskew'}
end

ease {72,2.5,outElastic,0,'tipsy'}
ease {72,2.5,outElastic,0,'drunk'}
ease {72,2.5,outElastic,0,'noteskew'}

for i=36,39.75,2 do
ease {i,.5,instant,156,'confusionoffset'}
ease {i+.5,.5,instant,314,'confusionoffset'}
ease {i+1,.5,instant,468,'confusionoffset'}
ease {i+1.5,.5,instant,0,'confusionoffset'}
end

ease {38.75,3,outElastic,0,'tipsy',0,'drunk'}

for i=3.5,4.5,2 do
ease {i,1,inOutSine,5,'rotationz'}
ease {i+1,1,inOutSine,-5,'rotationz'}
end

ease {5.5,1,inOutSine,5,'rotationz'}
ease {6.5,1,inOutSine,0,'rotationz'}
set {8,0,'tipsy',0,'drunk'}
set {7.5,20,'orient',50,'beat'}


for i=8,39,1 do
ease {i,0.75,impulse,-50,'tiny'}
end

set {40,0,'beat'}


set {55.5,100,'beat'}
set {72,0,'beat'}


ease {72,3,outElastic,6,'alternate',-3,'reverse'}
ease {74,3,outElastic,0,'alternate',0,'reverse'}
ease {76,3,outElastic,-6,'alternate',3,'reverse'}
ease {78,3,outElastic,0,'alternate',0,'reverse'}
ease {80,3,outElastic,6,'cross',-3,'reverse'}
ease {82,3,outElastic,0,'cross',0,'reverse'}
ease {84,3,outElastic,-6,'cross',3,'reverse'}
ease {86,3,outElastic,0,'cross',0,'reverse'}
ease {85,3,inExpo,100,'centerPlayfields'}
ease {88,3,popElastic,50,'centerPlayfields'}

--i was going to not do arrow gimmicks in this part but i did anyway lol
ease {88,0.5,inExpo,25,'tinyy1',-25,'tinyx1',10,'movey1'}
ease {88.5,1.5,bounce,-25,'tinyy1',25,'tinyx1',-60,'movey1'}
ease {90,1.5,outElastic,0,'tinyy1',0,'tinyx1',0,'movey1'}
ease {89.5,0.5,inExpo,25,'tinyy3',-25,'tinyx3',10,'movey3'}
ease {90,1.5,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3'}
ease {91.5,1.5,outElastic,0,'tinyy3',0,'tinyx3',0,'movey3'}
ease {91,0.5,inExpo,25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {91.5,1.5,bounce,-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {93,1.5,outElastic,0,'tinyy0',0,'tinyx0',0,'movey0'}
ease {92.5,0.5,inExpo,25,'tinyy2',-25,'tinyx2',10,'movey2'}
ease {93,1.5,bounce,-25,'tinyy2',25,'tinyx2',-60,'movey2'}
ease {94.5,1.5,outElastic,0,'tinyy2',0,'tinyx2',0,'movey2'}
ease {94,0.5,inExpo,25,'tinyy3',-25,'tinyx3',10,'movey3',25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {94.5,1.5,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3',-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {96,1.5,outElastic,0,'tinyy3',0,'tinyx3',0,'movey3',0,'tinyy0',0,'tinyx0',0,'movey0'}

ease {104.5,0.5,inExpo,25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {105,1.5,bounce,-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {106.5,1.5,outElastic,0,'tinyy0',0,'tinyx0',0,'movey0'}
ease {106,0.5,inExpo,25,'tinyy3',-25,'tinyx3',10,'movey3'}
ease {106.5,1.5,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3'}
ease {108,1.5,outElastic,0,'tinyy3',0,'tinyx3',0,'movey3'}
ease {107.5,0.5,inExpo,25,'tinyy1',-25,'tinyx1',10,'movey1'}
ease {108,1.5,bounce,-25,'tinyy1',25,'tinyx1',-60,'movey1'}
ease {109.5,1.5,outElastic,0,'tinyy1',0,'tinyx1',0,'movey1'}
ease {109,0.5,inExpo,25,'tinyy2',-25,'tinyx2',10,'movey2'}
ease {109.5,1.5,bounce,-25,'tinyy2',25,'tinyx2',-60,'movey2'}
ease {111,1.5,outElastic,0,'tinyy2',0,'tinyx2',0,'movey2'}

ease {120.5,0.5,inExpo,25,'tinyy1',-25,'tinyx1',10,'movey1'}
ease {121,1.5,bounce,-25,'tinyy1',25,'tinyx1',-60,'movey1'}
ease {122.5,1.5,outElastic,0,'tinyy1',0,'tinyx1',0,'movey1'}
ease {122,0.5,inExpo,25,'tinyy3',-25,'tinyx3',10,'movey3'}
ease {122.5,1.5,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3'}
ease {124,1.5,outElastic,0,'tinyy3',0,'tinyx3',0,'movey3'}
ease {123.5,0.5,inExpo,25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {124,1.5,bounce,-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {125.5,1.5,outElastic,0,'tinyy0',0,'tinyx0',0,'movey0'}
ease {125,0.5,inExpo,25,'tinyy2',-25,'tinyx2',10,'movey2'}
ease {125.5,1.5,bounce,-25,'tinyy2',25,'tinyx2',-60,'movey2'}
ease {127,1.5,outElastic,0,'tinyy2',0,'tinyx2',0,'movey2'}
ease {126.5,0.5,inExpo,25,'tinyy3',-25,'tinyx3',10,'movey3',25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {127,1,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3',-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {128,1.5,outElastic,0,'tinyy3',0,'tinyx3',0,'movey3',0,'tinyy0',0,'tinyx0',0,'movey0'}

ease {136.5,0.5,inExpo,25,'tinyy0',-25,'tinyx0',10,'movey0'}
ease {137,1.5,bounce,-25,'tinyy0',25,'tinyx0',-60,'movey0'}
ease {138.5,1.5,outElastic,0,'tinyy0',0,'tinyx0',0,'movey0'}
ease {138,0.5,inExpo,25,'tinyy2',-25,'tinyx2',10,'movey2'}
ease {138.5,1.5,bounce,-25,'tinyy2',25,'tinyx2',-60,'movey2'}
ease {140,1.5,outElastic,0,'tinyy2',0,'tinyx2',0,'movey2'}
ease {141,3,inExpo,0,'centerPlayfields'}
ease {144,3,popElastic,-50,'centerPlayfields'}

for i=139.5,143.5,1 do
ease {i+0.5,0.5,bounce,-25,'tinyy0',25,'tinyx0',-60,'movey0'}
end

for i=140,143.5,1 do
ease {i+0.5,0.5,bounce,-25,'tinyy3',25,'tinyx3',-60,'movey3'}
end

ease {144,2,outElastic,0,'tinyy0',0,'tinyx0',0,'movey0',0,'tinyy3',0,'tinyx3',0,'movey3'}

for i=96,103.5,0.5 do
ease {i,.25,instant,6,'alternate',-3,'reverse'}
ease {i+.25,0.25,instant,-6,'alternate',3,'reverse'}
end

ease {104,.25,instant,0,'alternate',0,'reverse'}

for i=128,135.5,0.5 do
ease {i,.25,instant,6,'alternate',-3,'reverse'}
ease {i+.25,0.25,instant,-6,'alternate',3,'reverse'}
end

ease {136,.25,instant,0,'alternate',0,'reverse'}

for i=96,103,1 do
ease {i,.25,instant,156,'confusionoffset'}
ease {i+.25,.25,instant,314,'confusionoffset'}
ease {i+.5,.25,instant,468,'confusionoffset'}
ease {i+.75,.25,instant,0,'confusionoffset'}
end

ease {104,4,popElastic,314,'confusionoffset'}
ease {116,3,popElastic,-314,'confusionoffset'}
ease {118.5,3,popElastic,314,'confusionoffset'}

for i=128,135,1 do
ease {i,.25,instant,156,'confusionoffset'}
ease {i+.25,.25,instant,314,'confusionoffset'}
ease {i+.5,.25,instant,468,'confusionoffset'}
ease {i+.75,.25,instant,0,'confusionoffset'}
end

ease {135,4,popElastic,314,'confusionoffset'}

--lazy to sync this part to the music
for i=144,197,3 do
ease {i,1.5,bounce,75,'tipsy'}
ease {i+1.5,1.5,bounce,-75,'tipsy'}
end

for i=144,197,3 do
ease {i,1.5,bounce,125,'drunk'}
ease {i+1.5,1.5,bounce,-125,'drunk'}
end

for i=144,198.5,1.5 do
ease {i,1.5,bounce,-75,'y'}
end

for i=144,197,3 do
ease {i,1.5,bounce,5,'rotationz'}
ease {i+1.5,1.5,bounce,-5,'rotationz'}
end

for i=144,198.5,1.5 do
ease {i,1.5,bounce,-25,'tinyy'}
end
-------------------------------------------------------

for i=200,227,2 do
ease {i,1,bounce,85,'tipsy'}
ease {i+1,1,bounce,-85,'tipsy'}
end

for i=200,227,2 do
ease {i,1,bounce,100,'drunk'}
ease {i+1,1,bounce,-100,'drunk'}
end

for i=200,227,1 do
ease {i,1,bounce,-50,'y'}
end

for i=200,227,2 do
ease {i,1,bounce,15,'rotationz'}
ease {i+1,1,bounce,-15,'rotationz'}
end

for i=200,227,1 do
ease {i,1,bounce,-50,'tinyy'}
end

--that reference to cering's "yggdrasil leaf" mod file
ease {224,3,inOutCirc,(SCREEN_CENTER_X-32 - P1:GetX()),'x',plr=1}
ease {224,3,inOutCirc,(P1:GetX() - SCREEN_CENTER_X+32),'x',plr=2}
ease {224,3,inOutCirc,-50,'flip'}
ease {288,3,inOutCirc,0,'x',plr=1}
ease {288,3,inOutCirc,0,'x',plr=2}
ease {288,3,inOutCirc,0,'flip'}

for i=227,291,1 do
ease {i,1,bounce,-50,'movey'}
end

ease {228,1,outSine,100,'arrowpath'}
ease {290.5,1,inSine,0,'arrowpath'}

for i=227,289,2 do
ease {i,1,bounce,-50,'tiny',plr=1}
ease {i+1,1,bounce,50,'tiny',plr=1}
ease {i,1,bounce,50,'tiny',plr=2}
ease {i+1,1,bounce,-50,'tiny',plr=2}
end

for i=259.5,291,2 do
ease {i,0.5,inSine,75,'bumpyx'}
ease {i+0.5,0.5,outCirc,0,'bumpyx'}
ease {i+1,0.5,inSine,-75,'bumpyx'}
ease {i+1.5,0.5,outCirc,0,'bumpyx'}
end

for i=291.5,323,4 do
ease {i,0.5,inSine,50,'bumpyx'}
ease {i+0.5,1,outCirc,0,'bumpyx'}
ease {i+2,0.5,inSine,-50,'bumpyx'}
ease {i+2.5,1,outCirc,0,'bumpyx'}
end

for i=323.5,339,2 do
ease {i,0.5,inSine,100,'bumpyx'}
ease {i+0.5,0.5,outCirc,0,'bumpyx'}
ease {i+1,0.5,inSine,-100,'bumpyx'}
ease {i+1.5,0.5,outCirc,0,'bumpyx'}
end

for i=339.5,355,1 do
ease {i,0.25,inSine,100,'bumpyx'}
ease {i+0.25,0.25,outCirc,0,'bumpyx'}
ease {i+0.5,0.25,inSine,-100,'bumpyx'}
ease {i+0.75,0.25,outCirc,0,'bumpyx'}
end

for i=356,378,2 do
ease {i,0.75,pop,75,'tipsy'}
ease {i+1,0.75,pop,-75,'tipsy'}
end


swap {292,1,outBack,'ludr'}
swap {294,1,outBack,'ldur'}
swap {296,1,outBack,'rudl'}
swap {298,1,outBack,'ldur'}
swap {300,1,outBack,'ruld'}
swap {302,1,outBack,'ldur'}
swap {304,1,outBack,'ulrd'}
swap {306,1,outBack,'ldur'}
ease {307,1,inOutCirc,100,'invert'}
ease {308,0.5,inOutCirc,0,'invert'}
ease {308.5,1,outCirc,50,'invert'}
ease {309,1,outCirc,35,'invert'}
ease {310,1,outCirc,25,'invert'}
ease {311,1,outCirc,35,'invert'}
ease {312,1,outCirc,25,'invert'}
ease {313,1,outCirc,10,'invert'}
ease {314,1,outCirc,0,'invert'}
ease {315,0.5,outCirc,100,'invert'}
ease {316,0.5,outCirc,0,'invert'}
ease {316.5,0.5,outCirc,100,'invert'}
ease {318,0.5,outCirc,0,'invert'}
ease {318.5,2,popElastic,100,'invert'}
swap {324,1,outBack,'ludr'}
swap {326,1,outBack,'ldur'}
swap {328,1,outBack,'rudl'}
swap {330,1,outBack,'ldur'}
swap {332,1,outBack,'ruld'}
swap {334,1,outBack,'ldur'}
swap {336,1,outBack,'ulrd'}
swap {338,1,outBack,'ldur'}
swap {340,1,outBack,'ludr'}
swap {342,1,outBack,'ldur'}
swap {344,1,outBack,'rudl'}
swap {346,1,outBack,'ldur'}
swap {348,1,outBack,'ruld'}
swap {350,1,outBack,'ldur'}
swap {352,1,outBack,'ulrd'}
swap {354,1,outBack,'ldur'}
set {356,50,'beat'}
set {380,0,'beat',0,'orient'}

ease {382,2,bounce,500,'boost'}

func {384, function()
SCREENMAN:GetTopScreen():vibrate()
end}

func {384, function()
SCREENMAN:GetTopScreen():effectmagnitude(5,5,5)
end}

func {400, function()
SCREENMAN:GetTopScreen():effectmagnitude(0,0,0)
end}

for i=384,399.5,0.5 do
ease {i,0.25,instant,50,'tipsy'}
ease {i+0.25,0.25,instant,-50,'tipsy'}
ease {i,0.25,instant,35,'drunk'}
ease {i+0.25,0.25,instant,-35,'drunk'}
ease {i,0.25,instant,10,'noteskew'}
ease {i+0.25,0.25,instant,-10,'noteskew'}
end

set{400,100,'disablemines'}

ease {400,2.5,outElastic,0,'tipsy'}
ease {400,2.5,outElastic,0,'drunk'}
ease {400,2.5,outElastic,0,'noteskew'}
ease {400,2.5,inBack,200,'mini'}
	
for i=324,355,1 do
ease {i,1,bounce,-10,'reverse'}
end

for i=4,7.75,1 do
local buildup = 1+(i-4)*2
ease {i,1,bounce,0.025*buildup,'bgzoom'}
end

for i=4,7.75,1 do
local buildup = 1+(i-4)*1
ease {i,0.5,instant,1*buildup,'bgrotate'}
ease {i+0.5,0.5,instant,-1*buildup,'bgrotate'}
end

ease {8,3,outElastic,0,'bgrotate'}

for i=8,39,1 do
ease {i,1,bounce,0.1,'bgzoom'}
end

for i=40,55,2 do
ease {i,2,bounce,0.1,'bgzoom'}
end

for i=40,55,4 do
ease {i,2,bounce,2,'bgrotate'}
ease {i+2,2,bounce,-2,'bgrotate'}
end

for i=56,63,1 do
ease {i,1,bounce,0.15,'bgzoom'}
end

for i=56,63,2 do
ease {i,1,bounce,3,'bgrotate'}
ease {i+1,1,bounce,-3,'bgrotate'}
end

for i=64,71.75,0.5 do
ease {i,0.5,bounce,0.15,'bgzoom'}
end

for i=72,139,2 do
ease {i,2,bounce,0.1,'bgzoom'}
end

for i=140,143.75,0.5 do
ease {i,0.5,bounce,0.15,'bgzoom'}
end

for i=144,155,1.5 do
ease {i,1.5,bounce,0.25,'bgzoom'}
end

for i=156,157,1 do
ease {i,1,bounce,0.25,'bgzoom'}
end

for i=158,196.5,1.5 do
ease {i,1.5,bounce,0.25,'bgzoom'}
end

for i=198,227,1 do
ease {i,1,bounce,0.1,'bgzoom'}
end

for i=228,259,1 do
ease {i,1,bounce,1.10,'screenzoom'}
end

for i=260,291,1 do
ease {i,1,bounce,1.15,'screenzoom'}
end

for i=260,291,2 do
ease {i,1,bounce,3,'screenrotate'}
ease {i+1,1,bounce,-3,'screenrotate'}
end

for i=292,323,1 do
ease {i,1,bounce,0.1,'bgzoom'}
end

for i=324,339,0.5 do
ease {i,.5,bounce,0.1,'bgzoom'}
end

for i=340,355.5,0.25 do
ease {i,.25,bounce,0.1,'bgzoom'}
end

for i=356,379,1 do
ease {i,1,bounce,0.1,'bgzoom'}
end

-- spellcards or some shit
card {0,7,'the beginning people never asked for',0,'#FFFFFF'}
card {9,39.5,'i second land land the tango',3,'#6DA3DE'}
card {40,71,'who fucking landed the process?',4,'#1AB04F'}
card {72,87,'ease {72,15,outElastic,6,\'whyarewedoingthis\'',2,'#FF0000'}
card {72,87,'ease {72,15,outElastic,6,\'whyarewedoingthis\'}',2,'#FF0000'}
card {89,143.5,'boing boing boing',2,'#9500FF'}
card {200,227,'now its time to go fast',7,'#00FF59'}
card {228,291,'oh hey look a yggdrasil leaf reference!',3,'#BD7524'}
card {292,353,'the fact that youve come through the columnswaps',8,'#6ADBE6'}
card {356,378,'did you know sasakure.UK makes good music for maimai?',3,'#8C40B8'}
card {384,400,'ultimate test! did you hit or miss it?',69,'#000000'}