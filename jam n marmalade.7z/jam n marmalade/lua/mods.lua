if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end

-- chart2lua stuff--it's helpful and can make vocals as smooth as possible --
local b =
{0.000,
1.000,
2.000,
2.750,
3.500,
4.000,
5.000,
6.000,
6.750,
7.500,
8.000,
10.000,
12.000,
13.500,
15.000,
16.000,
18.000,
20.000,
21.500,
23.000,
24.000,
26.000,
28.000,
29.500,
31.000,
32.000,
34.000,
36.000,
37.000,
38.000,
39.000,
40.000,
42.000,
44.000,
45.500,
47.000,
48.000,
50.000,
52.000,
53.500,
54.000,
54.500,
55.000,
55.500,
56.000,
58.000,
60.000,
61.500,
63.000,
64.000,
66.000,
68.000,
69.500,
71.000,
72.000,
72.750,
74.000,
74.750,
76.000,
76.750,
77.500,
79.000,
80.000,
80.750,
82.000,
82.750,
84.000,
84.750,
86.000,
87.000,
88.000,
88.750,
90.000,
90.750,
92.000,
92.750,
93.500,
95.000,
96.000,
98.000,
100.000,
101.500,
103.000,
104.000,
106.000,
108.000,
109.500,
111.000,
112.000,
114.000,
116.000,
117.500,
119.000,
120.000,
122.000,
124.000,
125.500,
127.000,
128.000,
130.000,
152.000,
154.000,
156.000,
158.000,
160.000,
162.000,
164.000,}

local invert_switch =
{104.500,
105.250,
106.500,
107.250,
108.500,
109.250,
110.500,
111.250,
112.500,
113.250,
114.500,
115.250,
116.500,
117.250,
118.500,
119.250,
120.500,
121.250,
122.500,
123.250,
124.500,
125.250,
126.500,
127.250,
128.500,
129.250,
130.500,
131.250,}

local the_j =
{24.000,
28.000,
32.000,
34.000,
34.000,
36.000,
37.000,
38.000,
39.000,
41.000,
43.000,
45.000,
49.000,
51.000,
53.000,
57.000,
59.000,
61.000,
65.000,
67.000,
69.000,
136.000,
136.500,
137.000,
138.000,
138.750,
140.000,
140.500,
141.000,
142.000,
142.750,
144.000,
144.500,
145.000,
146.000,
146.750,
148.000,
148.500,
149.000,
150.000,
150.750,
153.000,
155.000,
157.000,
161.000,
163.000,
165.000,}

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end

---------------------------------------
--------Let's Define Modifiers!--------
---------------------------------------

definemod{'bgzoom', function(p)
	itg2bg:zoom(1+p)
end}

definemod{'bgrotate', function(p)
	itg2bg:rotationz(p)
end}

definemod{'bgy', function(p)
	itg2bg:y(scy+p)
end}

local rr = function(angleX, angleY, angleZ)
    local sinX,cosX,sinY,cosY,sinZ,cosZ = math.sin(angleX),math.cos(angleX),math.sin(angleY),math.cos(angleY),math.sin(angleZ),math.cos(angleZ)
    return { math.atan2(-cosX*sinY*sinZ-sinX*cosZ,cosX*cosY), math.asin(-cosX*sinY*cosZ+sinX*sinZ), math.atan2(-sinX*sinY*cosZ-cosX*sinZ,cosY*cosZ) }
end

aux {'coolrotationx','coolrotationy','coolrotationz'}
node {'coolrotationx','coolrotationy','coolrotationz',function(xd, yd, zd, plr)
    local d2r = math.pi / 180
    local ang = rr(xd * d2r, yd * d2r, zd * d2r)
    local rx, ry, rz = xd, yd, zd
    local cx, cy, cz = ang[1] * 100, ang[2] * 100, ang[3] * 100
        return rx, ry, rz, cx, cy, cz
    end,
    'rotationx','rotationy','rotationz','confusionxoffset','confusionyoffset','confusionzoffset'
}
alias {'confusionoffset', 'confusionzoffset'}

--code from "Hurry Hurry"!
itg2bg:zoomtowidth(SCREEN_WIDTH)
	itg2bg:zoomtoheight(SCREEN_HEIGHT)
	itg2bg:x(SCREEN_CENTER_X)
	itg2bg:y(SCREEN_CENTER_Y)
	itg2bg:diffuse(1,1,1,1)
	
	local p1DefaultX = P1:GetX()
local p2DefaultX = P2:GetX()
local defaultZ = P1:GetZ()

definemod {'centerPlayfields', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end}

definemod { 'centerP1', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
end}

definemod {'centerP2', function(percent) 
    local scale = percent / 100
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end} --i didnt write that mod starundrscre did it, credit to them ig

condor_const1 = math.sqrt(math.pow(SCREEN_WIDTH/2,2)+math.pow(SCREEN_HEIGHT/2,2))
	condor_const2 = 180+math.deg(math.atan(SCREEN_HEIGHT/SCREEN_WIDTH))
	function condor_screenmotion(zm,ang,x,y)
		if not x then x = SCREEN_WIDTH/2 end
		if not y then y = SCREEN_HEIGHT/2 end

		local screen = SCREENMAN:GetTopScreen()

		screen:x(x+(condor_const1*zm*math.cos((ang+condor_const2)/180*math.pi)));
		screen:y(y+(condor_const1*zm*math.sin((ang+condor_const2)/180*math.pi)));
		screen:zoom(zm)
	end

	definemod {'screenzoom', 'screenrotate', function(zm, ang)
		condor_screenmotion(zm,ang)
	end}



	
--funny mods go here:
setdefault{2.35,'xmod',100,'overhead',100,'dizzyholds',100,'modtimer',-50,'bumpyxoffset',-300,'bumpyxperiod',0,'bgzoom',100,'cover',50,'orient',1,'screenzoom'} --yes orient is a great mod

------------------------------------------------------
-------------------THE MAIN MODIFIERS-----------------
------------------------------------------------------
ease{-0.25,0.75,inOutCubic,15,'invert'}
ease{-0.25,0.25,inCubic,-15,'mini'}
ease{0,0.5,outCubic,0,'mini'}
ease{0.75,0.75,inOutCubic,-5,'invert'}
ease{0.75,0.25,inCubic,-15,'mini'}
ease{1,0.5,outCubic,0,'mini'}
ease{1.75,0.75,inOutCubic,10,'invert'}
ease{1.75,0.25,inCubic,-15,'mini'}
ease{2,0.5,outCubic,0,'mini'}
ease{2.5,0.75,inOutCubic,-10,'invert'}
ease{2.5,0.25,inCubic,-15,'mini'}
ease{2.75,0.5,outCubic,0,'mini'}
ease{3.25,0.75,inOutCubic,5,'invert'}
ease{3.25,0.25,inCubic,-15,'mini'}
ease{3.5,0.5,outCubic,0,'mini'}
ease{3.75,0.75,inOutCubic,15,'invert'}
ease{3.75,0.25,inCubic,-15,'mini'}
ease{4,0.5,outCubic,0,'mini'}
ease{4.75,0.75,inOutCubic,-5,'invert'}
ease{4.75,0.25,inCubic,-15,'mini'}
ease{5,0.5,outCubic,0,'mini'}
ease{5.75,0.75,inOutCubic,10,'invert'}
ease{5.75,0.25,inCubic,-15,'mini'}
ease{6,0.5,outCubic,0,'mini'}
ease{6.5,0.75,inOutCubic,-10,'invert'}
ease{6.5,0.25,inCubic,-15,'mini'}
ease{6.75,0.5,outCubic,0,'mini'}
ease{7.25,0.75,inOutCubic,0,'invert'}
ease{7.25,0.25,inCubic,-15,'mini'}
ease{7.5,0.5,outCubic,0,'mini'}

set{9,50,'beat'}
set{40,0,'beat'}

for i=9,31,2 do
local multiply=(i%2)*2-1
ease{i-0.5,0.5,inCubic,-25,'mini',-5*multiply,'invert'}
ease{i,1,outCubic,0,'mini',0,'invert'}
end

for i=9,31,8 do
swap{i-0.5,1,inOutBack,'durl'}
swap{i+1.5,1,inOutBack,'urld'}
swap{i+3.5,1,inOutBack,'rldu'}
swap{i+5.5,1,inOutBack,'ldur'}
end

for i=24,39,1 do
local multiply=(i%2)*2-1
ease{i,1,bounce,5*multiply,'rotationz'}
add{i,1,bounce,50*multiply,'tipsy'}
end

for i,v in ipairs(b) do
local multiply=(i%2)*2-1
set{v,0.1,'bgzoom'}
add{v,1,outCubic,-0.10,'bgzoom'}
ease{v,0.75,pop,35*multiply,'bumpyx'}
end

for i,v in ipairs(the_j) do
set{v,1.25,'screenzoom'}
local multiply=(i%2)*2-1
set{v,100*multiply,'tipsy',50*multiply,'drunk'}
ease{v,1,outBack,1,'screenzoom'}
ease{v,1,outBack,0,'tipsy',0,'drunk'}
end


for i=71.5,92,4 do
ease{i,1,inOutBack,6,'alternate',-3,'reverse'}
ease{i+1,1,inOutBack,0,'alternate',0,'reverse'}
ease{i+2,1,inOutBack,-6,'alternate',3,'reverse'}
ease{i+3,1,inOutBack,0,'alternate',0,'reverse'}
end

ease{94,10,inOutCubic,360*3,'coolrotationy'}

for i,v in ipairs(invert_switch) do
local multiply=(i%2)*2-1
ease{v-0.5,1,inOutExpo,-5*multiply,'flip'}
ease{v-0.5,0.5,inExpo,15,'mini'}
ease{v,0.5,outExpo,0,'mini'}
end

ease{120,12,inOutCubic,0,'coolrotationy'}

ease{132,1,inOutExpo,0,'flip'}
ease{132,0.5,bounceExpo,-50,'tiny'}

ease{132.25,0.25,outCirc,50,'tipsy'}
ease{132.5,0.25,outCirc,-39,'tipsy'}
ease{132.75,0.25,outCirc,56,'tipsy'}
ease{133,0.25,outCirc,-20,'tipsy'}
ease{133.25,0.25,outCirc,0,'tipsy'}
ease{133.75,0.25,outCirc,-60,'tipsy'}
ease{134,0.25,outCirc,0,'tipsy'}
ease{134.25,0.25,outCirc,-60,'tipsy'}
ease{134.75,0.25,outCirc,60,'tipsy'}
ease{135.25,0.75,outCirc,0,'tipsy'}
set{135.5,200,'beatz'}
set{168,0,'beatz'}

ease{158,2,inCubic,100,'centerPlayfields'}
ease{160,8,inOutCubic,360*3,'coolrotationy'}
ease{160,8,inCubic,600,'bgy'}
for pn=1,2 do
set{168,100,'disablemines'}
end

ease{168,1,outCubic,-250,'tipsy'}
ease{168,3,linear,-80,'flip'}
ease{168,1,outCubic,-125,'y'}
ease{169,1.5,inCubic,500,'y',-10,'tipsy'}