definemod{'bgkick', function(p)
	bg:xywh(scx,scy,sw+p,sh+p)
end}

definemod{'bgzoomy', function(p)
	bg:zoomy(p)
end}

definemod{'bgzoomx', function(p)
	bg:zoomx(p)
end}

definemod{'bgrotate', function(p)
	bg:rotationz(p)
end}

definemod{'bgbounce', function(p)
	bg:y(p)
end}

definemod{'bgrotatex', function(p)
	bg:rotationx(p)
end}

definemod{'bgrotatey', function(p)
	bg:rotationy(p)
end}

for i=15.5, 47, 1 do
ease {i, 0.5, inCubic, 50, 'bgkick'}
ease {i+0.5, 0.5, outCubic, 0, 'bgkick'}
end

ease {79.5, 1.2, bounce, 250, 'bgkick'}
ease {79.5, 1.2, bounce, 25, 'bgrotate'}

for i=80.7, 110, 1 do
ease {i, 0.5, outCubic, 150, 'bgkick'}
ease {i+0.5, 0.5, inCubic, 0, 'bgkick'}
end

for i=155.5, 226.5, 1 do
ease {i, 0.5, outCubic, 100, 'bgkick'}
ease {i+0.5, 0.5, inCubic, 0, 'bgkick'}
end

for i=227.5, 235.5, 2 do
ease {i, 1, impulse, 100, 'bgkick'}
end

for i=306.7, 319.5, 4 do
ease {i+3, 1, impulse, 100, 'bgkick'}
end

for i=323.7, 329.7, 1 do
ease {i, 1, bounce, 150, 'bgkick'}
end

for i=384.5, 483, 1 do
ease {i, 0.5, inCubic, 50, 'bgkick'}
ease {i+0.5, 0.5, outCubic, 0, 'bgkick'}
end

for i=483.5, 491.5, 2 do
ease {i, 1, impulse, 100, 'bgkick'}
end

ease {126.8, 1, inOutBack, 175, 'bgkick'}
ease {128.8, 1, inOutBack, 250, 'bgkick'}
ease {130.8, 1, inOutBack, 325, 'bgkick'}
ease {132.8, 1, inOutBack, 400, 'bgkick'}
ease {134.3, 1, inExpo, 0, 'bgkick'}
ease {135.3, 3, popElastic, 100, 'bgkick'}

for i=80.7, 108, 2 do
ease {i, 0.5, outCubic, -10, 'bgrotate'}
ease {i+0.5, 0.5, inCubic, 0, 'bgrotate'}
ease {i+1, 0.5, outCubic, 10, 'bgrotate'}
ease {i+1.5, 0.5, inCubic, 0, 'bgrotate'}
end

for i=275.7, 306.5, 4 do
ease {i, 2, inOutSine, -2, 'bgrotate'}
ease {i+2, 2, inOutSine, 2, 'bgrotate'}
end
ease {308, 3, outElastic, 0, 'bgrotate'}

for i=155.5, 226.5, 2 do
ease {i, 0.5, outCubic, -5, 'bgrotate'}
ease {i+0.5, 0.5, inCubic, 0, 'bgrotate'}
ease {i+1, 0.5, outCubic, 5, 'bgrotate'}
ease {i+1.5, 0.5, inCubic, 0, 'bgrotate'}
end

ease {115, 0.5, impulse, 200, 'bgkick'}
ease {115, 0.5, impulse, 15, 'bgrotate'}
ease {115.5, 0.5, impulse, 200, 'bgkick'}
ease {115.5, 0.5, impulse, -15, 'bgrotate'}
ease {116, 0.5, impulse, 200, 'bgkick'}
ease {116, 0.5, impulse, 15, 'bgrotate'}
ease {116.5, 0.5, impulse, 200, 'bgkick'}
ease {116.5, 0.5, impulse, -15, 'bgrotate'}
ease {117, 0.5, impulse, 200, 'bgkick'}
ease {117, 0.5, impulse, 15, 'bgrotate'}