if not P1 or not P2 then
	SCREENMAN:SystemMessage('"I hearby decree that Liebe Girls Academy \nis closed unless two players are here.\" - Mai') -- Report the error to the user
	return
end

-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end

-- judgment proxies
for pn = 1, 2 do
	local judgment = P[pn]("Judgment")
	judgment:sleep(9e9)
	judgment:hidden(1)
	PJ[pn]:SetTarget(judgment)
	PJ[pn]:xy(scx * (pn-0.5), scy)
end

-- combo proxies
for pn = 1, 2 do
	local combo = P[pn]("Combo")
	combo:sleep(9e9)
	combo:hidden(1)
	PC[pn]:SetTarget(combo)
	PC[pn]:xy(scx * (pn-0.5), scy)
end

xero.require('bgzoom')

	local p1DefaultX = P1:GetX()
local p2DefaultX = P2:GetX()
local defaultZ = P1:GetZ()

definemod { 'centerPlayfields', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end }

definemod { 'centerP1', function(percent) 
    local scale = percent / 100
    P1:x((scale*scx) + ((1-scale)*p1DefaultX))
end }

definemod { 'centerP2', function(percent) 
    local scale = percent / 100
    P2:x((scale*scx) + ((1-scale)*p2DefaultX))
end }

local rr = function(angleX, angleY, angleZ)
	local sinX,cosX,sinY,cosY,sinZ,cosZ = math.sin(angleX),math.cos(angleX),math.sin(angleY),math.cos(angleY),math.sin(angleZ),math.cos(angleZ)
	return { math.atan2(-cosX*sinY*sinZ-sinX*cosZ,cosX*cosY), math.asin(-cosX*sinY*cosZ+sinX*sinZ), math.atan2(-sinX*sinY*cosZ-cosX*sinZ,cosY*cosZ) }
end
aux {'coolrotationx','coolrotationy','coolrotationz'}
node {'coolrotationx','coolrotationy','coolrotationz',function(xd, yd, zd, plr)
	local d2r = math.pi / 180
	local ang = rr(xd * d2r, yd * d2r, zd * d2r)
	local rx, ry, rz = xd, yd, zd
	local cx, cy, cz = ang[1] * 100, ang[2] * 100, ang[3] * 100
	return rx, ry, rz, cx, cy, cz
	end,
	'rotationx','rotationy','rotationz','confusionxoffset','confusionyoffset','confusionzoffset'
}
alias {'confusionzoffset', 'confusionoffset'}

condor_const1 = math.sqrt(math.pow(SCREEN_WIDTH/2,2)+math.pow(SCREEN_HEIGHT/2,2))
	condor_const2 = 180+math.deg(math.atan(SCREEN_HEIGHT/SCREEN_WIDTH))
	function condor_screenmotion(zm,ang,x,y)
		if not x then x = SCREEN_WIDTH/2 end
		if not y then y = SCREEN_HEIGHT/2 end

		local screen = SCREENMAN:GetTopScreen()

		screen:x(x+(condor_const1*zm*math.cos((ang+condor_const2)/180*math.pi)));
		screen:y(y+(condor_const1*zm*math.sin((ang+condor_const2)/180*math.pi)));
		screen:rotationz(ang)
		screen:zoom(zm)
	end

	definemod {'screenzoom', 'screenrotate', function(zm, ang)
		condor_screenmotion(zm,ang)
	end}

-- credit to these people for the code: A-Saph, StarUndrscre & Condor

-- spellcards that im so bad at rating
card {0, 46, 'mai: "and your name is... WAIT IT ISNT "HIME SHIRASAGI" ITS "SHIRASAGI HIME"', 0,'#EBE481'}
card {47, 59, 'I know right? Piano all day, Yano-san is too persistent.', 3,'#FFFFFF'}
card {60, 78, 'yano switches and starts columnswapping', 1,'#A200FF'}
card {78, 110, 'liebe girls academy is closed today', 4,'#BD4BB3'}
card {114.9, 117, 'column swap-a-roo', 6,'#FA91BB'}
card {129.5, 133.5, 'how many arrows in this part did you handle?', 10,'#000000'}
card {147.5, 152, '\'"Wow" is right, for sure.\' - mai', 10,'#F70291'}
card {155.75, 160.75, 'the most bullshit part', 5,'#F79502'}
card {226.5, 233.5, 'the intimidating pink default background', 5,'#F9A6FF'}
card {361.5, 379.5, 'ease {361.3, 16, inOutSine, 400, \'columnSwaps\'}', 69,'#FF0000'}


-- your code goes here here:
setdefault {2.5, 'xmod', 100, 'overhead', 100, 'dizzyholds', 100, 'modtimer', 200, 'tiny0', 200, 'tiny1', 200, 'tiny2', 200, 'tiny3', -50, 'bumpyxoffset', -300, 'bumpyxperiod', -50, 'bumpyyoffset', -750, 'bumpyyperiod', 0, 'bgkick', 1, 'screenzoom'}
definemod {'text1x', 'text1y', function(x,y) pause:xy(x, y) end}
setdefault {325, 'text1x', 900, 'text1y',}
definemod {'text2x', 'text2y', function(x,y) remember:xy(x, y) end}
setdefault {325, 'text2x', 900, 'text2y'}

ease {0, 4, outElastic, 0, 'tiny0'}
ease {4, 4, outElastic, 0, 'tiny1'}
ease {8, 4, outElastic, 0, 'tiny2'}
ease {12, 4, outElastic, 0, 'tiny3'}
ease {14, 3, outSine, 100, 'centerPlayfields'}
set {14, 360, 'coolrotationy'}
ease {14, 2, outSine, 100, 'centerPlayfields'}
ease {14, 3, outSine, 0, 'coolrotationy'}

ease {16.5, 1, inOutSine, 13, 'rotationz'}
ease {17.5, 1, inOutSine, -13, 'rotationz'}
ease {18.75, 3, outElastic, 0, 'rotationz'}

for i=15.7, 46, 2 do
ease {i, 0.5, outCubic, -57, 'movey0', -15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+0.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i+1, 0.5, outCubic, -57, 'movey0', 15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+1.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i, 0.5, outCubic, -45, 'movey2', -25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+0.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i+1, 0.5, outCubic, -45, 'movey2', 25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+1.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i, 0.5, outCubic, -50, 'movey1', -35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+0.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i+1, 0.5, outCubic, -50, 'movey1', 35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+1.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i, 0.5, outCubic, -60, 'movey3', -25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+0.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
ease {i+1, 0.5, outCubic, -60, 'movey3', 25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+1.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
end

--SCREENMAN:GetTopScreen
for i=79.5, 112, 2 do
ease {i+1.2, 1, impulse, 1.05, 'screenzoom'}
end

for i=119.7, 125, 1 do
ease {i, 1, bounce, 1.05, 'screenzoom'}
end

ease {126.8, 1, inOutBack, 1.1, 'screenzoom'}
ease {128.8, 1, inOutBack, 1.2, 'screenzoom'}
ease {130.8, 1, inOutBack, 1.3, 'screenzoom'}
ease {132.8, 1, inOutBack, 1.4, 'screenzoom'}
ease {134.8, 1, inOutBack, 1, 'screenzoom'}

for i=323.7, 329.7, 2 do
ease {i+1, 1, impulse, 1.03, 'screenzoom'}
end

for i=330.7, 339.7, 1 do
ease {i+1, 1, bounce, 1.17, 'screenzoom'}
end

--

ease {47.5, 3, outElastic, 0, 'movey0',
0, 'movey1',
0, 'movey2',
0, 'movey3',
100, 'zoomx',
100, 'zoomy',
0, 'rotationy',
0, 'movex'}

ease {47.5, 4, popElastic, 240, 'drunky'}

ease {51.3, 1, outExpo, 5, 'movey0'}
ease {51.3, 1, outExpo, 5, 'movey2'}
ease {51.3, 1, outExpo, -5, 'movey1'}
ease {51.3, 1, outExpo, -5, 'movey3'}
ease {51.3, 1, outBack, -5, 'confusionoffset0',
-5, 'confusionoffset2',
5, 'confusionoffset1',
5, 'confusionoffset3',}

for i=52.3, 55, 1 do
ease {i, 0.5, outCubic, -5, 'movey0'}
ease {i, 0.5, outCubic, -5, 'movey2'}
ease {i, 0.5, outCubic, 5, 'movey1'}
ease {i, 0.5, outCubic, 5, 'movey3'}
ease {i+0.5, 0.5, outCubic, 5, 'movey0'}
ease {i+0.5, 0.5, outCubic, 5, 'movey2'}
ease {i+0.5, 0.5, outCubic, -5, 'movey1'}
ease {i+0.5, 0.5, outCubic, -5, 'movey3'}
end

ease {55.3, 0.5, outBack, -5, 'movey0'}
ease {55.3, 0.5, outBack, -5, 'movey2'}
ease {55.3, 0.5, outBack, 5, 'movey1'}
ease {55.3, 0.5, outBack, 5, 'movey3'}
ease {55.3, 0.5, outBack, 5, 'confusionoffset0',
5, 'confusionoffset2',
-5, 'confusionoffset1',
-5, 'confusionoffset3',}

ease {56.7, 0.5, outBack, 5, 'movey0'}
ease {56.7, 0.5, outBack, 5, 'movey2'}
ease {56.7, 0.5, outBack, -5, 'movey1'}
ease {56.7, 0.5, outBack, -5, 'movey3'}
ease {56.7, 0.5, outBack, -5, 'confusionoffset0',
-5, 'confusionoffset2',
5, 'confusionoffset1',
5, 'confusionoffset3',}

ease {59.3, 0.5, outBack, 0, 'movey0'}
ease {59.3, 0.5, outBack, 0, 'movey2'}
ease {59.3, 0.5, outBack, 0, 'movey1'}
ease {59.3, 0.5, outBack, 0, 'movey3'}
ease {59.3, 0.5, outBack, 0, 'confusionoffset0',
0, 'confusionoffset2',
0, 'confusionoffset1',
0, 'confusionoffset3',}

ease {60.2, 0.5, outQuad, -15, 'alternate'}
ease {61.2, 0.5, outQuad, 0, 'alternate'}

ease {61.65, 2, popElastic, 95, 'zoomx'}
ease {61.65, 2, popElastic, 105, 'zoomy'}

ease {60.7, 1, outQuad, 100, 'invert'}

ease {63.2, 1, outQuad, -15, 'alternate'}
ease {64.2, 0.5, inQuad, 0, 'alternate'}

ease {64.7, 2, popElastic, 95, 'zoomx'}
ease {64.7, 2, popElastic, 105, 'zoomy'}

ease {63.7, 2, outQuad, 0, 'invert'}

ease {67.3, 1, outExpo, 5, 'movey0'}
ease {67.3, 1, outExpo, 5, 'movey2'}
ease {67.3, 1, outExpo, -5, 'movey1'}
ease {67.3, 1, outExpo, -5, 'movey3'}
ease {67.3, 1, outBack, -5, 'confusionoffset0',
-5, 'confusionoffset2',
5, 'confusionoffset1',
5, 'confusionoffset3',}

for i=68.3, 71, 1 do
ease {i, 0.5, outCubic, -5, 'movey0'}
ease {i, 0.5, outCubic, -5, 'movey2'}
ease {i, 0.5, outCubic, 5, 'movey1'}
ease {i, 0.5, outCubic, 5, 'movey3'}
ease {i+0.5, 0.5, outCubic, 5, 'movey0'}
ease {i+0.5, 0.5, outCubic, 5, 'movey2'}
ease {i+0.5, 0.5, outCubic, -5, 'movey1'}
ease {i+0.5, 0.5, outCubic, -5, 'movey3'}
end

ease {71.3, 0.5, outCubic, -10, 'movey0'}
ease {71.3, 0.5, outCubic, -10, 'movey2'}
ease {71.3, 0.5, outCubic, 10, 'movey1'}
ease {71.3, 0.5, outCubic, 10, 'movey3'}
ease {71.3, 0.5, outBack, -10, 'confusionoffset0',
-10, 'confusionoffset2',
10, 'confusionoffset1',
10, 'confusionoffset3',}

ease {73, 1, outBack, -5, 'confusionoffset0',
-5, 'confusionoffset2',
5, 'confusionoffset1',
5, 'confusionoffset3',}

for i=73, 74, 1 do
ease {i, 0.5, outCubic, 5, 'movey0'}
ease {i, 0.5, outCubic, 5, 'movey2'}
ease {i, 0.5, outCubic, -5, 'movey1'}
ease {i, 0.5, outCubic, -5, 'movey3'}
ease {i+0.5, 0.5, outCubic, -5, 'movey0'}
ease {i+0.5, 0.5, outCubic, -5, 'movey2'}
ease {i+0.5, 0.5, outCubic, 5, 'movey1'}
ease {i+0.5, 0.5, outCubic, 5, 'movey3'}
end

ease {75.3, 1, outBack, -10, 'movey0'}
ease {75.3, 1, outBack, -10, 'movey2'}
ease {75.3, 1, outBack, 10, 'movey1'}
ease {75.3, 1, outBack, 10, 'movey3'}
ease {75.3, 1, outBack, -10, 'confusionoffset0',
-10, 'confusionoffset2',
10, 'confusionoffset1',
10, 'confusionoffset3',}

ease {77, 1, outBack, 0, 'movey0'}
ease {77, 1, outBack, 0, 'movey2'}
ease {77, 1, outBack, 0, 'movey1'}
ease {77, 1, outBack, 0, 'movey3'}
ease {77, 1, outBack, 0, 'confusionoffset0',
0, 'confusionoffset2',
0, 'confusionoffset1',
0, 'confusionoffset3',}

for i=79.5, 110, 2 do
ease {i, 1, inOutSine, 5, 'rotationz'}
ease {i+1, 1, inOutSine, -5, 'rotationz'}
end

for i=79.7, 110, 2 do
ease {i, 1, impulse, -35, 'tiny'}
ease {i+1, 1, impulse, -125, 'tiny'}
end

for i=155.7, 227.5, 1 do
ease {i, 1, impulse, -35, 'tiny'}
end

ease {111.7, 3, outElastic, 0, 'rotationz'}

for i=79.7, 110, 2 do
ease {i, 0.5, outCubic, -57, 'movey0', -15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+0.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i+1, 0.5, outCubic, -57, 'movey0', 15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+1.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i, 0.5, outCubic, -45, 'movey2', -25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+0.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i+1, 0.5, outCubic, -45, 'movey2', 25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+1.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i, 0.5, outCubic, -50, 'movey1', -35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+0.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i+1, 0.5, outCubic, -50, 'movey1', 35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+1.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i, 0.5, outCubic, -60, 'movey3', -25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+0.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
ease {i+1, 0.5, outCubic, -60, 'movey3', 25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+1.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
end

for i=111.5, 114, 2 do
ease {i, 0.5, inCirc, 75, 'bumpyx'}
ease {i+0.5, 0.5, outCirc, 0, 'bumpyx'}
ease {i+1, 0.5, inCirc, -75, 'bumpyx'}
ease {i+1.5, 0.5, outCirc, 0, 'bumpyx'}
end

ease {114.7, 0.5, inOutCirc, 50, 'tipsy'}
ease {114.7, 0.5, inOutCirc, 100, 'invert'}
ease {115.2, 0.5, inOutCirc, 0, 'invert'}
ease {115.7, 0.5, inOutCirc, 100, 'invert'}
ease {116.2, 0.5, inOutCirc, 0, 'invert'}
ease {116.7, 0.5, inOutQuint, 100, 'invert'}
ease {117.2, 2, inOutCirc, 0, 'tipsy'}
ease {117.2, 2, inOutCirc, 0, 'invert'}

ease {79.2, 0.5, inSine, 120, 'zoomx'}
ease {79.2, 0.5, inSine, 80, 'zoomy'}
ease {79.7, 1, outSine, 100, 'zoomx'}
ease {79.7, 1, outSine, 100, 'zoomy'}

ease {119.3, 1, outExpo, -75, 'tinyy', 25, 'tinyx', 15, 'rotationy'}

ease {119.3, 0.05, instant, -1, 'movex'}
ease {119.3, 0.05, instant, 1, 'movex'}

for i=119.4, 120.3, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {120.3, 3, outElastic, 0, 'tinyy', 0, 'tinyx', 0, 'rotationy'}

set {120.5, 0, 'movex'}
set {120.3, 100, 'beat'}
set {124, 0, 'beat'}

for i=120.3, 124, 2 do
ease {i, 1, inOutCirc, 10, 'movey0'}
ease {i, 1, inOutCirc, 10, 'movey2'}
ease {i, 1, inOutCirc, -10, 'movey1'}
ease {i, 1, inOutCirc, -10, 'movey3'}
ease {i+1, 1, inOutCirc, -10, 'movey0'}
ease {i+1, 1, inOutCirc, -10, 'movey2'}
ease {i+1, 1, inOutCirc, 10, 'movey1'}
ease {i+1, 1, inOutCirc, 10, 'movey3'}
end

ease {124.8, 0.5, outCubic, -5, 'movey0'}
ease {124.8, 0.5, outCubic, -5, 'movey2'}
ease {124.8, 0.5, outCubic, 5, 'movey1'}
ease {124.8, 0.5, outCubic, 5, 'movey3'}
ease {124.8, 0.5, outCubic, 5, 'movey0'}
ease {124.8, 0.5, outCubic, 5, 'movey2'}
ease {124.8, 0.5, outCubic, -5, 'movey1'}
ease {124.8, 0.5, outCubic, -5, 'movey3'}

ease {125.3, 0.5, outBack, 0, 'movey0'}
ease {125.3, 0.5, outBack, 0, 'movey2'}
ease {125.3, 0.5, outBack, 0, 'movey1'}
ease {125.3, 0.5, outBack, 0, 'movey3'}
ease {125.3, 0.5, outBack, 0, 'movey0'}
ease {125.3, 0.5, outBack, 0, 'movey2'}
ease {125.3, 0.5, outBack, 0, 'movey1'}
ease {125.3, 0.5, outBack, 0, 'movey3'}

ease {126.8, 1, inOutBack, 75, 'centerPlayfields'}
ease {126.8, 1, inOutBack, -15, 'alternate'}
ease {126.8, 1, inOutBack, 50, 'invert'}
ease {128.8, 1, inOutBack, 50, 'centerPlayfields'}
ease {128.8, 1, inOutBack, 0, 'alternate'}
ease {128.8, 1, inOutBack, 100, 'invert'}
ease {130.8, 1, inOutBack, 25, 'centerPlayfields'}
ease {130.8, 1, inOutBack, -15, 'alternate'}
ease {130.8, 1, inOutBack, 50, 'invert'}
ease {132.8, 1, inOutBack, 0, 'centerPlayfields'}
ease {132.8, 1, inOutBack, 0, 'alternate'}
ease {132.8, 1, inOutBack, 0, 'invert'}

-- what the fuck am i doing
ease {135.3, 8, inOutCirc, 200, 'centerPlayfields'}
ease {135.3, 0.5, inOutSine, 1, 'confusionoffset'}
ease {135.8, 0.5, inOutSine, -2, 'confusionoffset'}
ease {136.3, 0.5, inOutSine, 3, 'confusionoffset'}
ease {136.8, 0.5, inOutSine, -4, 'confusionoffset'}
ease {137.3, 0.5, inOutSine, 5, 'confusionoffset'}
ease {137.8, 0.5, inOutSine, -6, 'confusionoffset'}
ease {138.3, 0.5, inOutSine, 7, 'confusionoffset'}
ease {138.8, 0.5, inOutSine, -8, 'confusionoffset'}
ease {139.3, 0.5, inOutSine, 9, 'confusionoffset'}
ease {139.8, 0.5, inOutSine, -10, 'confusionoffset'}
ease {140.3, 0.5, inOutSine, 11, 'confusionoffset'}
ease {140.8, 0.5, inOutSine, -12, 'confusionoffset'}
ease {141.3, 0.5, inOutSine, 13, 'confusionoffset'}
ease {141.8, 0.5, inOutSine, -14, 'confusionoffset'}
ease {142.3, 0.5, inOutSine, 15, 'confusionoffset'}
ease {142.8, 0.5, inOutSine, -16, 'confusionoffset'}
ease {143.3, 8, inOutCirc, 0, 'centerPlayfields'}
ease {143.3, 0.5, inOutSine, 18, 'confusionoffset'}
ease {143.8, 0.5, inOutSine, -20, 'confusionoffset'}
ease {144.3, 0.5, inOutSine, 22, 'confusionoffset'}
ease {144.8, 0.5, inOutSine, -24, 'confusionoffset'}
ease {145.3, 0.5, inOutSine, 26, 'confusionoffset'}
ease {145.8, 0.5, inOutSine, -28, 'confusionoffset'}
ease {146.3, 0.5, inOutSine, 30, 'confusionoffset'}
ease {146.8, 0.5, inOutSine, -32, 'confusionoffset'}
ease {147.3, 0.5, inOutSine, 34, 'confusionoffset'}
ease {147.8, 0.5, inOutSine, -36, 'confusionoffset'}
ease {148.3, 0.5, inOutSine, 38, 'confusionoffset'}
ease {148.8, 0.5, inOutSine, -40, 'confusionoffset'}
ease {149.3, 0.5, inOutSine, 42, 'confusionoffset'}
ease {149.8, 0.5, inOutSine, -42, 'confusionoffset'}
ease {150.3, 0.5, inOutSine, 44, 'confusionoffset'}
ease {150.8, 0.5, inOutSine, -46, 'confusionoffset'}
ease {151.3, 0.5, inOutSine, 48, 'confusionoffset'}
ease {151.8, 0.5, inOutSine, -50, 'confusionoffset'}
ease {152.3, 2, outElastic, 0, 'confusionoffset'}
ease {143.3, 12, inOutQuad, 360*3, 'coolrotationy'}
ease {152.3, 2, inQuad, 900, 'movey', plr = 1}
ease {156.3, 2, inQuad, 900, 'movey', plr = 2}
ease {157.3, 2, outQuad, 0, 'movey', plr = 1}
ease {161.3, 2, outQuad, 0, 'movey', plr = 2}
ease {185.3, 2, inQuad, 900, 'movey', plr = 1}
ease {188.3, 2, inQuad, 900, 'movey', plr = 2}
ease {189.3, 2, outQuad, 0, 'movey', plr = 1}
ease {191.3, 2, outQuad, 0, 'movey', plr = 2}

for i=16, 47, 1 do
ease {i, 1, impulse, -40, 'tiny'}
end

for i=155.7, 226.5, 2 do
ease {i, 1, outBack, 25, 'bumpyx'}
ease {i+1, 1, outBack, -25, 'bumpyx'}
end
ease {187.3, 5, impulse, 314, 'confusionoffset'}

ease {227, 1, outBack, 0, 'bumpyx'}

ease {166, 1.5, outExpo, 75, 'tinyy', -50, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {167.2, 1, outCirc, -60, 'tinyy', -2, 'rotationz', -100, 'movey', 50, 'tinyx'}
ease {168.2, 0.5, inCirc, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx',}
ease {168.7, 2, popElastic, 80, 'zoomy', 110, 'zoomx'}

for i=169.7, 227, 2 do
ease {i, 0.5, outCubic, -57, 'movey0', -15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+0.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i+1, 0.5, outCubic, -57, 'movey0', 15, 'confusionoffset0', -50, 'tinyy0'}
ease {i+1.5, 0.5, inCubic, 0, 'movey0', 0, 'confusionoffset0', 0, 'tinyy0'}
ease {i, 0.5, outCubic, -45, 'movey2', -25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+0.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i+1, 0.5, outCubic, -45, 'movey2', 25, 'confusionoffset2', -50, 'tinyy2'}
ease {i+1.5, 0.5, inCubic, 0, 'movey2', 0, 'confusionoffset2', 0, 'tinyy2'}
ease {i, 0.5, outCubic, -50, 'movey1', -35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+0.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i+1, 0.5, outCubic, -50, 'movey1', 35, 'confusionoffset1', -50, 'tinyy1'}
ease {i+1.5, 0.5, inCubic, 0, 'movey1', 0, 'confusionoffset1', 0, 'tinyy1'}
ease {i, 0.5, outCubic, -60, 'movey3', -25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+0.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
ease {i+1, 0.5, outCubic, -60, 'movey3', 25, 'confusionoffset3', -50, 'tinyy3'}
ease {i+1.5, 0.5, inCubic, 0, 'movey3', 0, 'confusionoffset3', 0, 'tinyy3'}
end

set {243, 100, 'beat'}

for i=15.5, 47, 2 do
ease {i, 0.5, inSine, 75, 'bumpyx'}
ease {i+0.5, 0.5, outSine, 0, 'bumpyx'}
ease {i+1, 0.5, inSine, -75, 'bumpyx'}
ease {i+1.5, 0.5, outSine, 0, 'bumpyx'}
end

for i=363.5, 379, 2 do
ease {i, 0.5, inSine, 75, 'bumpyx'}
ease {i+0.5, 0.5, outSine, 0, 'bumpyx'}
ease {i+1, 0.5, inSine, -75, 'bumpyx'}
ease {i+1.5, 0.5, outSine, 0, 'bumpyx'}
end

for i=363.5, 379, 4 do
ease {i, 1, outElastic, 100, 'invert'}
ease {i+1, 1, outElastic, 0, 'invert'}
ease {i+2, 1, outElastic, 100, 'flip'}
ease {i+3, 1, outElastic, 0, 'flip'}
end

for i=363.5, 379, 1 do
ease {i, 1, popElastic, 15, 'noteskewx'}
end

for i=363.5, 378, 2 do
ease {i, 1, inOutSine, 5, 'rotationz'}
ease {i+1, 1, inOutSine, -5, 'rotationz'}
end

ease {379.5, 3, outElastic, 0, 'rotationz'}

ease {226.5, 1, inOutSine, 100, 'drunk'}
ease {226.5, 1, inOutSine, 25, 'tipsy'}

for i=227.5, 235.5, 2 do
ease {i, 1, impulse, -75, 'tiny'}
end

for i=227.5, 235.5, 2 do
ease {i, 1, impulse, -25, 'mini'}
end

for i=226.5, 236.5, 4 do
ease {i, 2, inOutSine, -5, 'rotationz'}
ease {i+2, 2, inOutSine, 5, 'rotationz'}
end

ease {236.75, 2, inOutSine, 5, 'rotationz'}

ease {239.5, 3, outElastic, 0, 'rotationz'}
ease {239.5, 3, inOutSine, 0, 'drunk'}
ease {239.5, 3, inOutSine, 0, 'tipsy'}

func {243.7, function() pause:settext('pause break!!') end}
ease {243, 1.7, outExpo, 325, 'text1x', 400, 'text1y'}
for i=244.7, 275, 1 do
ease {i, 1, bounce, 390, 'text1y'}
end
ease {275.7, 1, inQuad, 800, 'text1y'}

func {387.5, function() remember:settext('DO YOU STILL REMEMBER THE PARTS?') end}
ease {387.5, 1, outExpo, 325, 'text2x', 400, 'text2y'}
for i=388.5, 392.5, 1 do
ease {i, 1, bounce, 390, 'text2y'}
end
ease {393.5, 1, inQuad, 800, 'text2y'}

ease {279, 1, outBack, 20, 'movey1', -20, 'movey2', 10, 'confusionoffset1', -20, 'confusionoffset2'}
ease {280, 1, outBack, -30, 'movey1', 30, 'movey2', -15, 'confusionoffset1', 25, 'confusionoffset2'}
ease {281, 1, outBack, 35, 'movey1', -35, 'movey2', 35, 'confusionoffset1', -35, 'confusionoffset2'}
ease {283, 3, outElastic, 0, 'movey1', 0, 'movey2', 0, 'confusionoffset1', 0, 'confusionoffset2'}
ease {283, 3, popElastic, 400, 'drunk'}
ease {287, 1, outBack, 10, 'movey1', -10, 'movey2', 5, 'confusionoffset1', -10, 'confusionoffset2'}
ease {288, 1, outBack, -15, 'movey1', 15, 'movey2', -15, 'confusionoffset1', 20, 'confusionoffset2'}
ease {288, 1, outBack, -5, 'movex0', 5, 'movex3'}
ease {289, 1, outBack, 0, 'movex0', 0, 'movex3'}
ease {290, 1, impulse, -10, 'movey0', 10, 'confusionoffset0'}
ease {290.5, 1, impulse, -10, 'movey1', 5, 'confusionoffset0'}
ease {291.8, 1, impulse, -10, 'movey3', -10, 'confusionoffset3'}
ease {289, 1, outBack, 20, 'movey1', -20, 'movey2', 25, 'confusionoffset1', -30, 'confusionoffset2'}
ease {291.8, 3, outElastic, 0, 'movey1', 0, 'movey2', 0, 'confusionoffset1', 0, 'confusionoffset2'}
ease {291.8, 3, popElastic, 400, 'drunk'}
set {294.5, 0, 'beat'}
ease {294.5, 0.5, outCirc, 80, 'tinyy', -20, 'tinyx', -2, 'rotationz', 20, 'movey'}
ease {295, 1, outCirc, -60, 'tinyy', 2, 'rotationz', -100, 'movey', 50, 'tinyx'}

for i=295, 296, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {296.05, 0.5, instant, 0, 'movex'}
ease {296, 1, inCirc, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx',}
ease {297, 2, popElastic, 80, 'zoomy', 110, 'zoomx'}
ease {298, 1, inOutCirc, 100, 'invert'}
ease {299, 1, inOutCirc, 0, 'invert'}
ease {298.5, 0.5, outCirc, 80, 'tinyy', -20, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {299.3, 2.3, bounce, -50, 'tinyy', 45, 'tinyx', 2, 'rotationz', -20, 'movey'}
ease {301.6, 2.3, bounce, -50, 'tinyy', 45, 'tinyx', -2, 'rotationz', -20, 'movey'}
ease {303.9, 1.5, bounce, -50, 'tinyy', 45, 'tinyx', 2, 'rotationz', -20, 'movey'}
ease {305.4, 1, outElastic, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx'}
ease {305.4, 2, popElastic, 30, 'confusionoffset'}
set {307, 100, 'beat'}

ease {311, 1, outBack, 5, 'movey1', -5, 'movey2', 5, 'confusionoffset1', -10, 'confusionoffset2'}
ease {312, 1, outBack, 0, 'movey1', 0, 'movey2', 0, 'confusionoffset1', 0, 'confusionoffset2'}
ease {312, 1, outCirc, 80, 'tinyy', -20, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {313, 1, outCirc, -60, 'tinyy', -2, 'rotationz', -100, 'movey', 50, 'tinyx'}

for i=313, 314.45, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {314.5, 0.5, instant, 0, 'movex'}
ease {314.5, 1, inCirc, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx',}
ease {315.5, 2, popElastic, 80, 'zoomy', 110, 'zoomx'}

ease {319.1, 1, outBack, -5, 'movey1', 5, 'movey2', -5, 'confusionoffset1', 10, 'confusionoffset2'}
ease {320.1, 0.5, outExpo, 5, 'movey1', -5, 'movey2', -5, 'confusionoffset1', 10, 'confusionoffset2'}
ease {320.6, 0.5, outExpo, -5, 'movey1', 5, 'movey2', -5, 'confusionoffset1', 10, 'confusionoffset2'}
ease {321.1, 0.5, outExpo, 5, 'movey1', -5, 'movey2', -5, 'confusionoffset1', 10, 'confusionoffset2'}
ease {322.1, 0.5, outExpo, 0, 'movey1', 0, 'movey2', 0, 'confusionoffset1', 0, 'confusionoffset2'}
ease {322.1, 0.5, impulse, -15, 'movey0', 15, 'confusionoffset0'}
ease {322.5, 0.5, impulse, -15, 'movey2', -10, 'confusionoffset2'}
ease {323, 0.75, bounce, -45, 'movey0', 25, 'confusionoffset0'}
ease {324, 0.5, impulse, -15, 'movey1', 5, 'confusionoffset1'}
ease {324.4, 0.5, impulse, -15, 'movey3', -15, 'confusionoffset3'}
ease {324.9, 0.5, impulse, -15, 'movey1', 5, 'confusionoffset1'}
ease {326.1, 0.5, impulse, -15, 'movey0', 15, 'confusionoffset0'}
ease {326.6, 0.5, impulse, -15, 'movey3', -15, 'confusionoffset3'}
ease {327, 0.75, bounce, -45, 'movey0', 25, 'confusionoffset0'}
ease {328.3, 0.5, impulse, -15, 'movey3', -15, 'confusionoffset3'}
ease {328.8, 0.5, impulse, -15, 'movey2', -10, 'confusionoffset2'}
ease {329.3, 0.5, impulse, -15, 'movey3', -15, 'confusionoffset3'}

ease {330, 1, outCirc, 80, 'tinyy', -20, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {331, 3, outCirc, -80, 'tinyy', -2, 'rotationz', -150, 'movey', 60, 'tinyx'}
set {331, 0, 'beat'}

for i=331, 338.95, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {339, 0.5, instant, 0, 'movex'}
ease {339, 0.5, inCirc, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx',}
ease {339.5, 2, popElastic, 80, 'zoomy', 110, 'zoomx'}

ease {347.5, 1, inOutSine, 80, 'drunky'}
set {347.5, 250, 'drunkyspeed'}

ease {359.5, 1, outElastic, 0, 'drunky'}
set {359.5, 0, 'drunkyspeed'}

ease {385, 1, inOutSine, 80, 'drunky'}
set {385, 250, 'drunkyspeed'}

ease {443, 3, outElastic, 0, 'drunky'}
set {443, 0, 'drunkyspeed'}

ease {385, 3, inOutSine, 50, 'beat'}

ease {359.3, 1.5, bounce, -50, 'tiny0', -10, 'movey0'}
ease {359.4, 1.5, bounce, -100, 'tiny1', -20, 'movey1'}
ease {359.5, 1.5, bounce, -150, 'tiny2', -30, 'movey2'}
ease {359.6, 1.5, bounce, -200, 'tiny3', -40, 'movey3'}

ease {360.3, 1.5, inOutSine, 0, 'coolrotationy', 100, 'centerPlayfields'}
ease {381.3, 6, inOutSine, 360, 'coolrotationy', 0, 'centerPlayfields'}
ease {385, 2, inQuad, 900, 'movey', plr = 1}
ease {389, 2, inQuad, 900, 'movey', plr = 2}
ease {390, 2, outQuad, 0, 'movey', plr = 1,}
ease {393, 2, outQuad, 0, 'movey', plr = 2}

ease {398, 1.5, outExpo, 75, 'tinyy', -50, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {399.5, 1, outCirc, -60, 'tinyy', -2, 'rotationz', -100, 'movey', 50, 'tinyx'}
ease {400.5, 0.5, inCirc, 0, 'tinyy', 0, 'rotationz', 0, 'movey', 0, 'tinyx',}
ease {401, 2, popElastic, 80, 'zoomy', 110, 'zoomx'}

ease {417, 2, inQuad, 900, 'movey', plr = 1}
ease {419, 2, inQuad, 900, 'movey', plr = 2}
ease {422, 2, outQuad, 0, 'movey', plr = 1}
ease {425, 2, outQuad, 0, 'movey', plr = 2}

ease {442, 1.5, outExpo, 75, 'tinyy', -50, 'tinyx', 2, 'rotationz', 20, 'movey'}
ease {443.5, 1, outCirc, -80, 'tinyy', 20, 'tinyx', -2, 'rotationz', -20, 'movey'}

for i=443.5, 448.95, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {449, 1, outCirc, 0, 'tinyy', 0, 'tinyx', 0, 'rotationz', 0, 'movey'}
ease {449, 0.05, instant, 0, 'movex'}

ease {450, 1, outExpo, 75, 'tinyy', -50, 'tinyx', -2, 'rotationz', 20, 'movey'}
ease {451, 1, outCirc, -80, 'tinyy', 20, 'tinyx', 2, 'rotationz', -20, 'movey'}
for i=451, 456.95, 0.1 do
ease {i, 0.05, instant, -2, 'movex'}
ease {i+0.05, 0.05, instant, 2, 'movex'}
end

ease {457, 1, outCirc, 0, 'tinyy', 0, 'tinyx', 0, 'rotationz', 0, 'movey'}
ease {457, 0.05, instant, 0, 'movex'}
ease {460.5, 1, outExpo, 100, 'invert'}
ease {460.5, 1, outExpo, 15, 'movey', 2, 'rotationz'}
ease {461.5, 1, outExpo, 0, 'invert'}
ease {461.5, 1, outExpo, 25, 'movey', 4, 'rotationz'}
ease {463, 1, outExpo, 100, 'invert'}
ease {463, 1, outExpo, -15, 'movey', -2, 'rotationz'}
ease {465, 1, outExpo, 0, 'invert'}
ease {465, 1, outExpo, 0, 'movey', 0, 'rotationz'}

set {476, 300, 'beat'}
set {479, 0, 'beat'}

ease {483.5, 1, inOutSine, 100, 'drunk'}
ease {483.5, 1, inOutSine, 25, 'tipsy'}

for i=483.5, 491.5, 2 do
ease {i, 1, impulse, -75, 'tiny'}
end

for i=483.5, 491.5, 2 do
ease {i, 1, impulse, -25, 'mini'}
end

for i=483.5, 491.5, 4 do
ease {i, 2, inOutSine, -5, 'rotationz'}
ease {i+2, 2, inOutSine, 5, 'rotationz'}
end

ease {492, 2, inOutSine, 5, 'rotationz'}

ease {494, 3, outElastic, 0, 'rotationz'}
ease {494, 3, inOutSine, 0, 'drunk'}
ease {494, 3, inOutSine, 0, 'tipsy'}
ease {499.5, 8, outSine, 0, 'coolrotationy', 628, 'confusionoffset'}
ease {508, 3, inBack, 360*2, 'coolrotationy', -900, 'movey'}

set {508, 100, 'disablemines'}